/*jslint vars: true, sloppy: true */
/*global $, window, angular, console */

/**
 * Diplomacy App
 * @author ghalex
 */

var app = angular.module('diplomacyApp', ['ui.keypress', 'ui.event'])
	.constant('useMockups', false)
	.constant('version', '@{version}')
	.constant('debug', false)
	.constant('unitOfTime', 1000)
    .constant("D", window.Diplomacy)
    .factory("serverUrl", function (debug) {
		return "http://localhost\\:8088";
	})
	.factory("hub", function () {
		
		var hub = $.connection.diplomacyHub;
		return hub;
	})
    .run(function ($rootScope, hub) {
        
        hub.client.update = function (msg) {
            console.log(msg);
        };
    });