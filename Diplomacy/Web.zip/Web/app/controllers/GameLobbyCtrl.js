/*jslint vars: true, sloppy: true */
/*global $, angular, console, window */

/**
 * GameLobbyController. 
 * @author ghalex
 */
var GameLobbyCtrl = function ($scope, hub, unitOfTime, $rootScope) {
	
    $scope.games = [];
    $scope.connected = false;
	$scope.joinedGame = "";
		       
	$scope.connect = function () {
        hub.connection.start();
    };
	
	$scope.disconnect = function () {
        hub.connection.stop();
    };
	
	$scope.newGame = function () {
        var gameID = hub.server.newGame();
    };
    
    $scope.joinGame = function (gameId) {
        hub.server.joinGame(gameId);
    };
    
	$scope.leaveGame = function (gameId) {
        hub.server.leaveGame(gameId);
		$scope.joinedGame = "";
    };
	
	$scope.runGame = function (gameId) {
        hub.server.runGame(gameId, 1);
    };
	
	$scope.stopGame = function (gameId) {
        hub.server.stopGame(gameId);
    };
	
	$scope.deleteGame = function (gameId) {
        hub.server.deleteGame(gameId);
    };
	
    hub.client.updateRegion = function (region) {
        $scope.$apply(function () {
        });
    };
	
	// Add HUB listeners
    hub.client.listGames = function (games) {
        $scope.$apply(function () {
			$scope.games = games;
        });
    };
	
	hub.client.joinGame = function (gameId, level) {
		$scope.$apply(function () {
			$scope.joinedGame = gameId;
			$rootScope.$broadcast('game-joined', {gameId: gameId, level: JSON.parse(level)});
        });
	};
	
	hub.connection.stateChanged(function (e) {
		
		if (e.newState === $.signalR.connectionState.connected) {
			$scope.connected = true;
			hub.server.listGames();
		} else {
			$scope.connected = false;
			$scope.games = [];
		}
	});
};
