/*jslint vars: true, sloppy: true, plusplus: true */
/*global $, L, angular, console, window, document, google, GeoJSON */


/**
 * CountryController. 
 * @author ghalex
 */
var MapCtrl = function ($scope, $rootScope, D) {
	
	var mapKey = '37274fcb889148c3b64046e650f3d4b5',
		mapType = google.maps.MapTypeId.ROADMAP,
		mapCenter = new google.maps.LatLng(42, 2);
    
	function initMap() {
	
        $scope.map = new google.maps.Map(
            document.getElementById('map'),
            {
                center: new google.maps.LatLng(45, 5),
                zoom: 5,
                mapTypeControl: false,
                panControl: false,
                zoomControl: false,
                streetViewControl: false,
                mapTypeId: google.maps.MapTypeId.ROADMAP,
                minZoom: 5,
                maxZoom: 10,
                styles: [
                    {
                        featureType: "administrative.country",
                        elementType: "geometry.stroke",
                        stylers: [
                            { weight: 2 },
                            { color: "#570000" }
                        ]
                    },
                    {
                        featureType: "all",
                        elementType: "geometry.fill",
                        stylers: [{
                            hue: "#EABD8F"
                        }, {
                            saturation: 50
                        }, {
                            lightness: 0
                        }, {
                            gamma: 0.5
                        }]
                        
                    },
                    {
                        featureType: "administrative.locality",
                        elementType: "labels",
                        stylers: [
                            { visibility: "off" }
                        ]
                    },
                    {
                        featureType: "water",
                        elementType: "geometry.fill",
                        stylers: [{
                            color: "#F2E0C6"
                        }]
                        
                    },
                    {
                        featureType: "road",
                        elementType: "all",
                        stylers: [
                            { visibility: "off" }
                        ]
                    }
                ]
            }
        );
        
        // For test
        window.googleMap = $scope.map;
	}
	
    function loadLevel (level) {
        
        var loader = new D.Loader(),
			i = 0;
        
		
		for (i = 0; i < level.Countries.length; i++) {
			
			loader.events.on('country-loaded', function (country) {
            	
				country.addToMap($scope.map);
				country.events.on('region-click', function (region) {
					$rootScope.$broadcast('region-click', region);
				});
            
				google.maps.event.addListener($scope.map, "click", function () {
					$rootScope.$broadcast('region-click', null);
					country.deselectAllRegions();
				});
			});
        
        	// Load France
        	loader.loadCountry(level.Countries[i]);
		}
		
        
        
    }
	
	$rootScope.$on('game-joined', function (evt, data) {
		loadLevel(data.level);
	});
    
    
    // Init map & load data
	initMap();

};
