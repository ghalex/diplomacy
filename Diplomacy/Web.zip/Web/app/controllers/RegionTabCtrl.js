/*jslint vars: true, sloppy: true */
/*global $, angular, console, window */


/**
 * RegionTabCtrl. 
 * @author ghalex
 */
var RegionTabCtrl = function ($scope, $rootScope) {
	
    $scope.region = null;
	$scope.show = false;
    
    $rootScope.$on('region-click', function (evt, region) {
        $scope.$apply(function () {
            $scope.region = region;
			
			if ($scope.show !== (region !== null)) {
				$scope.show = (region !== null);
			}
        });
    });
};
