/*jslint vars: true, sloppy: true */
/*global $, angular, console, window */


/**
 * CountryController. 
 * @author ghalex
 */
var EconomyCtrl = function ($scope, $rootScope) {
	
	$scope.country = {};
    $scope.region = null;
    
    // TODO: do this
    $rootScope.$on('region-click', function (evt, region) {
        $scope.$apply(function () {
            $scope.region = region;
        });
    });
};
