/*jslint vars: true, sloppy: true */
/*global D */


(function (exports, jQuery) {

    /**
	 * EventDispatcher class is used to catch and dispatch custom events.
	 * 
	 * @class EventDispatcher
	 * @module core
	 * @version 0.1.0
	 * @author Alexandru Ghiura
	 */
	var EventDispatcher = function (cfg) {
		this.events = {};
	};

	EventDispatcher.prototype = {

		/**
		 * Add listeners
		 * 
		 * @param eventName
		 * @param fn
		 * 
		 */
		on: function (eventName, fn, context) {
            
            var f = context ? jQuery.proxy(fn, context) : fn,
                events = this.events[eventName] = this.events[eventName] || [];
 
            fn.key = 'fn' + jQuery.now();
            fn.proxy = f;
            
            events[f.key] = f;
		},

		/**
		 * Fire an event
		 * 
		 * @param {String} eventName
		 * @param {Object} params
		 */
		fire: function (eventName, params) {
			var functions = this.events[eventName],
				key;
				
			for (key in functions) {
				
				if (typeof functions[key] === 'function') {
					var fn = functions[key];
					fn.apply(this, [params]);
				}
			}
		},

		/**
		 * Remove event
		 *
		 * @param {String} eventName
		 * @param {Function} fn
		 */
		detach: function (eventName, fn) {
			var events = this.events[eventName];

            if (events.hasOwnProperty(fn.key)) {
                delete events[fn.proxy || fn];
            }
            
			return;
		}
	};

	// Exports
	exports.EventDispatcher = EventDispatcher;
    
}(D, D.jQuery));

