/*jslint vars: true, sloppy: true */
/*global define, console */

/**
 * Diplomacy App
 * @author ghalex
 */

define(['angular', 'angular.ui.keypress', 'angular.ui.event'], function (angular) {
    angular.module('diplomacyApp', ['ng', 'ui.keypress', 'ui.event'])
        .constant('version', '@{version}')
        .constant('unitOfTime', 1000)
        .run(function ($rootScope) {
            
            console.log("Starting app...");
            console.log("App started...");
            
        });
});
