
/*jslint vars: true, sloppy: true */
/*global require, document, console */

require.config({
    baseUrl: '/web/app',
    paths: {
        'jQuery': '../js/jquery-2.0.3',
        'angular': '../js/angular',
        'angular.ui.keypress': '../js/angular-keypress',
        'angular.ui.event': '../js/angular-event'
    },
    shim: {
        'jQuery': {exports: 'jQuery'},
        'angular': {exports: 'angular'},
        'angular.ui.keypress': ['angular'],
        'angular.ui.event': ['angular']
    }
});

require(["jQuery", "angular", "app"], function ($, angular) {
    
    $(function () {
        angular.bootstrap(document, ['diplomacyApp']);
    });
});