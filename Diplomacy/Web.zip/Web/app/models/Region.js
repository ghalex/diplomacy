/*jslint vars: true, sloppy: true, plusplus: true */
/*global D, google */

(function (exports, jQuery, EventDispatcher) {

    var Region = function (options) {
        this.geometries = [];
        this.events = new EventDispatcher();
        this.options = jQuery.extend({}, this.options, options);
    };
    
    Region.prototype = {
        
        options: {
            clickable: true,
            fillColor: "#8DD3C7",
            fillOpacity: 0.5,
            strokeColor: "#550000",
            strokeOpacity: 0.8,
            strokeWeight: 2
        },
        
        setMap: function (map) {

            jQuery.each(this.geometries, function (index, geometry) {
                geometry.setMap(map);
            });
        },
        
        addGeometries: function (geometries) {
            
            this.geometries = geometries.concat(this.geometries);
            
            jQuery.each(this.geometries, jQuery.proxy(function (index, geometry) {
                
                geometry.setOptions(this.options);
                google.maps.event.addListener(geometry, "click", jQuery.proxy(this.onGeometryClick, this));
                
            }, this));
        },
        
        select: function () {
            jQuery.each(this.geometries, function (index, geometry) {
                geometry.setOptions({fillColor: "#FF0000"});
            });
            
            this.isSelected = true;
        },
        
        deselect: function () {
            var color = this.options.fillColor;
            
            jQuery.each(this.geometries, function (index, geometry) {
                geometry.setOptions({fillColor: color});
            });
            
            this.isSelected = false;
        },
        
        onGeometryClick: function (evt) {
            this.events.fire('click', this);
        }
    };
    
    exports.Region = Region;
        
}(D, D.jQuery, D.EventDispatcher));