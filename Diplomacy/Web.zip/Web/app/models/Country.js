/*jslint vars: true, sloppy: true, plusplus: true */
/*global D */

(function (exports, jQuery, EventDispatcher) {

    var Country = function () {
        this.regions = [];
        this.events = new EventDispatcher();
    };
    
    Country.prototype = {
        
        addRegion: function (region) {
            this.regions.push(region);
            
            region.events.on('click', this.onRegionClick, this);
        },
        
        addToMap: function (map) {
            this.setMap(map);
        },
        
        removeFromMap: function () {
            this.setMap(null);
        },
        
        setMap: function (map) {

            jQuery.each(this.regions, function (index, region) {
                region.setMap(map);
            });
        },
        
        deselectAllRegions: function () {
            jQuery.each(this.regions, function (index, region) {
                region.deselect();
            });
        },
        
        onRegionClick: function (region) {
            
            this.deselectAllRegions();
            region.select();
			
            this.events.fire('region-click', region);
        }
    };
    
    exports.Country = Country;
    
}(D, D.jQuery, D.EventDispatcher));