/*jslint vars: true, sloppy: true */
/*global window, jQuery */

var D = D || {};

D.jQuery = jQuery;
