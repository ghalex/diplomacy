/*jslint vars: true, sloppy: true */
/*global jQuery, console */

/** Tab plugin **/
(function ($) {
    
    $.fn.tab = function (options) {
      
        return this.each(function () {
            
            var btns = $(this).children('.tab-btn');
            var content = $(this).children('.tab-content');
            
            btns.delegate("> div", "click", function (evt) {
                btns.children().removeClass("selected");
                content.children().removeClass("selected");
                
                var index = btns.children().index(evt.currentTarget);
                $(evt.currentTarget).addClass("selected");
                
                $(content.children()[index]).addClass("selected");
            });
        });
    };
}(jQuery));